from django.shortcuts import render
from django.db.models import Count
from .models import IrrigationPrediction
from django.contrib.auth.decorators import login_required

import joblib
import os
from django.conf import settings

@login_required
def dashboard(request):
    total = IrrigationPrediction.objects.count()

    # Count by irrigation method
    method_counts = IrrigationPrediction.objects.values('result').annotate(count=Count('result'))

    # Most used method
    most_used = None
    if method_counts:
        most_used = max(method_counts, key=lambda x: x['count'])['result']

    # Recent records
    recent = IrrigationPrediction.objects.all().order_by('-created_at')[:5]

    context = {
        "total": total,
        "most_used": most_used,
        "recent": recent,
        "method_counts": method_counts
    }

    return render(request, "dashboard/dashboard.html", context)



# Build correct paths using BASE_DIR
MODEL_PATH = os.path.join(settings.BASE_DIR, 'modelapp', 'models', 'model.pkl')
SOIL_ENCODER_PATH = os.path.join(settings.BASE_DIR, 'modelapp', 'models', 'le_soil.pkl')
CROP_ENCODER_PATH = os.path.join(settings.BASE_DIR, 'modelapp', 'models', 'le_crop.pkl')
WATER_ENCODER_PATH = os.path.join(settings.BASE_DIR, 'modelapp', 'models', 'le_water.pkl')
OUTPUT_ENCODER_PATH = os.path.join(settings.BASE_DIR, 'modelapp', 'models', 'le_output.pkl')

# Load models
model = joblib.load(MODEL_PATH)
le_soil = joblib.load(SOIL_ENCODER_PATH)
le_crop = joblib.load(CROP_ENCODER_PATH)
le_water = joblib.load(WATER_ENCODER_PATH)
le_output = joblib.load(OUTPUT_ENCODER_PATH)

@login_required
def predict(request):
    if request.method == "POST":
        soil = request.POST['soil']
        crop = request.POST['crop']
        temp = float(request.POST['temperature'])
        hum = float(request.POST['humidity'])
        rain = float(request.POST['rainfall'])
        water = request.POST['water']

        try:
            # 🔸 Basic validation
            if not (0 <= temp <= 60):
                return render(request, "system/result.html", {"result": "Invalid Temperature"})
            if not (0 <= hum <= 100):
                return render(request, "system/result.html", {"result": "Invalid Humidity"})
            if not (0 <= rain <= 500):
                return render(request, "system/result.html", {"result": "Invalid Rainfall"})

            # 🔸 Encode inputs
            soil_enc = le_soil.transform([soil])[0]
            crop_enc = le_crop.transform([crop])[0]
            water_enc = le_water.transform([water])[0]

            # 🔸 Prediction
            prediction = model.predict([[soil_enc, crop_enc, temp, hum, rain, water_enc]])
            result = le_output.inverse_transform(prediction)[0]

            # 🔹 Recommendation Logic
            recommendation = ""
            suggestion = ""

            if result == "Drip":
                recommendation = "Drip irrigation is best for conserving water and delivering it directly to plant roots."
                suggestion = "Use drip lines, irrigate early morning or evening, and monitor soil moisture regularly."

            elif result == "Sprinkler":
                recommendation = "Sprinkler irrigation is suitable for uniform water distribution across the field."
                suggestion = "Avoid using during high winds. Best for medium rainfall and moderate water availability."

            elif result == "Surface":
                recommendation = "Surface irrigation is effective when water availability is high and land is level."
                suggestion = "Ensure proper field leveling to avoid water loss and uneven distribution."

            # 🔹 Smart Tips based on inputs
            tips = []

            if temp > 35:
                tips.append("High temperature detected: Increase irrigation frequency.")

            if hum < 40:
                tips.append("Low humidity: Risk of evaporation loss is high.")

            if rain > 150:
                tips.append("High rainfall: Avoid over-irrigation.")

            if soil == "Sandy":
                tips.append("Sandy soil: Water drains quickly, frequent irrigation needed.")

            if water == "Low":
                tips.append("Low water availability: Prefer water-saving techniques like drip irrigation.")

            # 🔸 Save to DB
            IrrigationPrediction.objects.create(
                soil_type=soil,
                crop_type=crop,
                temperature=temp,
                humidity=hum,
                rainfall=rain,
                water_availability=water,
                result=result
            )

            return render(request, "system/result.html", {
                "result": result,
                "recommendation": recommendation,
                "suggestion": suggestion,
                "tips": tips
            })

        except Exception as e:
            return render(request, "system/result.html", {"result": f"Error: {str(e)}"})

    return render(request, "system/predict.html")

def history(request):
    records = IrrigationPrediction.objects.all().order_by('-created_at')
    
    return render(request, "system/history.html", {
        "records": records
    })