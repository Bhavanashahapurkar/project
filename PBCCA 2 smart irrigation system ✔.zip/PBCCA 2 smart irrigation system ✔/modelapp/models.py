from django.db import models

class IrrigationPrediction(models.Model):
    soil_type = models.CharField(max_length=50)
    crop_type = models.CharField(max_length=50)
    temperature = models.FloatField()
    humidity = models.FloatField()
    rainfall = models.FloatField()
    water_availability = models.CharField(max_length=20)
    result = models.CharField(max_length=50)

    created_at = models.DateTimeField(auto_now_add=True)