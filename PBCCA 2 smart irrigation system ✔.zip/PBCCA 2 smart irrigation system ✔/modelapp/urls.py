from django.urls import path
from .views import *

app_name = "modelapp"

urlpatterns = [

    path('dashboard/',dashboard,name="dashboard"),
    path('predict/',predict,name="predict"),
    path('history/', history, name='history'),
    

]