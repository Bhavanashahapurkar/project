import json
from datetime import datetime, timedelta

from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import send_mail
from django.conf import settings

from .models import SensorData, Alert

# 🔒 Cooldown tracker
last_email_time = None


@csrf_exempt
def sensor_api(request):
    global last_email_time

    if request.method == "POST":
        try:
            data = json.loads(request.body)

            distance = float(data.get("distance", 0))
            soil = int(data.get("soil", 0))
            temperature = data.get("temperature")
            humidity = data.get("humidity")

            # Save sensor data
            SensorData.objects.create(
                distance=distance,
                soil=soil,
                temperature=temperature,
                humidity=humidity,
            )

            # 🚨 Alert condition
            if soil < 1000 and distance > 5:
                now = datetime.now()

                if last_email_time is None or (now - last_email_time) > timedelta(minutes=5):

                    message = f"Soil is dry! Distance: {distance} cm, Soil: {soil}"

                    # Save alert
                    Alert.objects.create(
                        distance=distance,
                        soil=soil,
                        message=message
                    )

                    # Send email
                    send_mail(
                        subject="🚨 Soil Dry Alert!",
                        message=message,
                        from_email=settings.EMAIL_HOST_USER,
                        recipient_list=["receiver_email@gmail.com"],
                        fail_silently=False,
                    )

                    last_email_time = now

            return JsonResponse({"status": "success"})

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})

    return JsonResponse({"error": "Only POST allowed"})


def dashboard(request):
    history = SensorData.objects.order_by('-created_at')[:10]
    return render(request, "sensor/dashboard.html", {
        "history": history
    })

def latest_data(request):
    data = SensorData.objects.last()

    if data:
        return JsonResponse({
            "distance": data.distance,
            "soil": data.soil,
            "temperature": data.temperature,
            "humidity": data.humidity,
            "time": data.created_at.strftime("%H:%M:%S")
        })
    return JsonResponse({})


def chart_data(request):
    data = SensorData.objects.order_by('-created_at')[:20][::-1]

    return JsonResponse({
        "labels": [d.created_at.strftime("%H:%M:%S") for d in data],
        "distance": [d.distance for d in data],
        "soil": [d.soil for d in data],
        "temperature": [d.temperature for d in data],
        "humidity": [d.humidity for d in data],
    })


def alert_history(request):
    alerts = Alert.objects.order_by('-created_at')
    return render(request, "sensor/alerts.html", {"alerts": alerts})