from django.urls import path
from .views import *

app_name = "SensorApp"

urlpatterns = [

    path('api/sensor/', sensor_api, name="sensorApi"),
    path('api/latest/', latest_data, name="sensor_latest_data"),
    path('api/chart/', chart_data, name="sensor_chart_data"),
    path('Sensordashboard/', dashboard, name="sensorDashboard"),
    path('alerts/', alert_history, name="sensor_alert_history"),
    

]