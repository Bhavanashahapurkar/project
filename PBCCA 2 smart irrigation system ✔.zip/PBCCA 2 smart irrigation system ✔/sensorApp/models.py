from django.db import models

class SensorData(models.Model):
    distance = models.FloatField()
    soil = models.IntegerField()
    temperature = models.FloatField(null=True, blank=True)
    humidity = models.FloatField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.created_at} - {self.distance} cm"


class Alert(models.Model):
    distance = models.FloatField()
    soil = models.IntegerField()
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Alert at {self.created_at}"