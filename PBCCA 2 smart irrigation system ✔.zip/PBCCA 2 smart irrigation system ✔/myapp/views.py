# users/views.py
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout
from django.contrib.auth import get_user_model
from django.core.mail import send_mail

from django.contrib.auth.views import LoginView
from django.core.paginator import Paginator
from django.db.models import Avg
from django.db.models import Q
import logging

from django.conf import settings

from .forms import *
from .models import *

from modelapp.views import dashboard

def base(request):
    return render(request, 'base.html')


def signup_view(request):

    if request.method == "POST":
        form = CustomUserCreationForm(request.POST, request.FILES)

        if form.is_valid():
            user = form.save()
            login(request, user)  # automatically log in after signup
            return redirect("dashboard")  # redirect to dashboard

    else:
        form = CustomUserCreationForm()

    return render(request, "registration/signup.html", {"form": form})



class CustomLoginView(LoginView):
    def get_success_url(self):
        user = self.request.user
        if user.is_superuser or user.is_staff:
            return '/admin/'  # Redirect admin users to Django admin dashboard
        return super().get_success_url()  # Normal users go to 'dashboard'

# Handle user logout
# def logout_view(request):
#     logout(request)
#     return redirect('login')

# profile
@login_required
def profile_view(request):
    return render(request, 'account/profile.html', {'user': request.user})

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import ProfileForm

@login_required
def edit_profile(request):
    user = request.user  # Get the current logged-in user

    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=user)  # Pre-fill the form with user's current data
        if form.is_valid():
            form.save()  # Save the updated data to the database
            return redirect('profile')  # Redirect to profile page (or dashboard, etc.)
    else:
        form = ProfileForm(instance=user)  # Display the form with user's current data

    return render(request, 'account/edit_profile.html', {'form': form})



# about
def about(request):
    return render(request, 'about/about.html')

# chat
@login_required
def user_list_view(request):
    users = get_user_model().objects.exclude(id=request.user.id)  
    return render(request, 'users/user_list.html', {'users': users})


@login_required
def chat_view_by_id(request, user_id):
    other_user = get_object_or_404(CustomUser, id=user_id)
    messages = Message.objects.filter(
        (Q(sender=request.user) & Q(receiver=other_user)) |
        (Q(sender=other_user) & Q(receiver=request.user))
    ).order_by('timestamp')

    if request.method == 'POST':
        text = request.POST.get('text')
        image = request.FILES.get('image')
        Message.objects.create(sender=request.user, receiver=other_user, text=text, image=image)
        return redirect('chat', user_id=other_user.id)  # ✅ Corrected: use user_id instead of username

    return render(request, 'users/chat.html', {
        'messages': messages,
        'receiver': other_user
    })

# Feedback
logger = logging.getLogger(__name__)

@login_required
def feedback_view(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            feedback.user = request.user
            feedback.save()

            # --- Prepare email for admins ---
            admin_emails = []
            if getattr(settings, "ADMINS", None):
                admin_emails = [addr for _, addr in settings.ADMINS if addr]

            # fallback to DEFAULT_FROM_EMAIL if ADMINS is empty
            if not admin_emails and getattr(settings, "DEFAULT_FROM_EMAIL", None):
                admin_emails = [settings.DEFAULT_FROM_EMAIL]

            if admin_emails:
                subject = f"New Feedback from {request.user.username}"
                message_lines = [
                    f"User: {request.user.get_full_name() or request.user.username}",
                    f"Email: {request.user.email}",
                    "",
                    "---- Feedback ----",
                    form.cleaned_data.get('message', 'No feedback text provided.'),
                    "",
                    f"Submitted on: {feedback.created_at if hasattr(feedback, 'created_at') else 'N/A'}",
                    f"View in admin: {request.build_absolute_uri(f'/admin/yourapp/feedback/{feedback.pk}/change/')}"
                ]
                message = "\n".join(message_lines)

                try:
                    send_mail(
                        subject=subject,
                        message=message,
                        from_email=getattr(settings, "DEFAULT_FROM_EMAIL", None),
                        recipient_list=admin_emails,
                        fail_silently=False,
                    )
                except Exception as e:
                    logger.exception("Failed to send feedback email: %s", e)

            return render(request, 'feedback/feedback_thanks.html')  # confirmation page

    else:
        form = FeedbackForm()

    return render(request, 'feedback/feedback.html', {'form': form})

@login_required
def view_feedbacks(request):
    if request.user.is_superuser:
        feedbacks = Feedback.objects.all().order_by('-created_at')
        return render(request, 'feedback/view_feedbacks.html', {'feedbacks': feedbacks})
    else:
        return redirect('dashboard')

    ## ========= Main|Application|Functionality_2O_8O_O7P1_2Q5 ## =========

